"""Smart Attendance Management System Flask factory."""

from __future__ import annotations

from datetime import timedelta
from flask import Flask

from config import (
    BASE_DIR,
    EXPORT_DIR,
    FACE_DIR,
    INSTANCE_DIR,
    MODEL_DIR,
    PHOTO_DIR,
    QR_DIR,
    Config,
)


def create_app() -> Flask:
    """Create and configure the Flask application."""
    for path in (INSTANCE_DIR, PHOTO_DIR, FACE_DIR, QR_DIR, MODEL_DIR, EXPORT_DIR):
        path.mkdir(parents=True, exist_ok=True)

    app = Flask(
        __name__,
        template_folder="templates",
        static_folder=str(BASE_DIR / "static"),
        static_url_path="/static",
    )
    app.config.from_object(Config)
    app.permanent_session_lifetime = timedelta(hours=8)

    from app.db import init_app as init_db_app

    init_db_app(app)

    from app.routes import register_routes

    register_routes(app)
    return app
