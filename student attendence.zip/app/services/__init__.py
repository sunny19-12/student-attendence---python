"""Service layer for recognition, QR tokens and reports."""
