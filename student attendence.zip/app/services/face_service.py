"""
Face detection and recognition.

Primary engine: OpenCV LBPH (opencv-contrib).
Optional engine: the `face_recognition` library (dlib) when it imports cleanly.
Haar cascade is used to locate faces before either matcher runs.
"""

from __future__ import annotations

import pickle
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from flask import current_app
from PIL import Image

from config import FACE_DIR, MODEL_DIR
from app.models import list_students

LBPH_MODEL = MODEL_DIR / "lbph.yml"
LBPH_LABELS = MODEL_DIR / "lbph_labels.pkl"
CASCADE_NAME = "haarcascade_frontalface_default.xml"


def _cascade() -> cv2.CascadeClassifier:
    path = Path(cv2.data.haarcascades) / CASCADE_NAME
    classifier = cv2.CascadeClassifier(str(path))
    if classifier.empty():
        raise RuntimeError("Failed to load Haar face cascade from OpenCV data files.")
    return classifier


def _has_face_recognition() -> bool:
    try:
        import face_recognition  # noqa: F401

        return True
    except Exception:
        return False


def decode_image_bytes(data: bytes) -> np.ndarray | None:
    array = np.frombuffer(data, dtype=np.uint8)
    image = cv2.imdecode(array, cv2.IMREAD_COLOR)
    return image


def detect_faces(gray: np.ndarray) -> list[tuple[int, int, int, int]]:
    cascade = _cascade()
    faces = cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(80, 80))
    return [tuple(map(int, f)) for f in faces]


def extract_face_from_file(photo_path: Path) -> np.ndarray | None:
    """Return a 200x200 grayscale face crop, or None if no face is found."""
    with Image.open(photo_path) as img:
        img = img.convert("RGB")
        frame = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detect_faces(gray)
    if not faces:
        return None
    x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
    crop = gray[y : y + h, x : x + w]
    return cv2.resize(crop, (200, 200))


def register_student_face(student_pk: int, photo_path: Path) -> bool:
    """Crop and store a training face. Retrains the LBPH model afterwards."""
    crop = extract_face_from_file(photo_path)
    if crop is None:
        return False
    FACE_DIR.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(FACE_DIR / f"{student_pk}.png"), crop)
    train_recognizer()
    return True


def _lbph_available() -> bool:
    return hasattr(cv2, "face") and hasattr(cv2.face, "LBPHFaceRecognizer_create")


def train_recognizer() -> int:
    """Train LBPH from stored face crops. Returns number of trained faces."""
    images: list[np.ndarray] = []
    labels: list[int] = []
    for path in FACE_DIR.glob("*.png"):
        try:
            label = int(path.stem)
        except ValueError:
            continue
        img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if img is None:
            continue
        images.append(cv2.resize(img, (200, 200)))
        labels.append(label)
    if not images or not _lbph_available():
        return 0
    recognizer = cv2.face.LBPHFaceRecognizer_create(radius=1, neighbors=8, grid_x=8, grid_y=8)
    recognizer.train(images, np.array(labels, dtype=np.int32))
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    recognizer.write(str(LBPH_MODEL))
    LBPH_LABELS.write_bytes(pickle.dumps(labels))
    return len(images)


def _match_lbph(face_gray: np.ndarray) -> tuple[int | None, float]:
    if not LBPH_MODEL.exists() or not _lbph_available():
        trained = train_recognizer()
        if not trained:
            return None, 999.0
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(str(LBPH_MODEL))
    label, confidence = recognizer.predict(cv2.resize(face_gray, (200, 200)))
    return int(label), float(confidence)


def _match_face_recognition(frame_bgr: np.ndarray) -> tuple[int | None, float]:
    """Optional dlib-based matcher using registered photos as encodings."""
    import face_recognition

    rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    locations = face_recognition.face_locations(rgb)
    encodings = face_recognition.face_encodings(rgb, locations)
    if not encodings:
        return None, 1.0

    known_encodings = []
    known_ids = []
    from config import PHOTO_DIR

    for student in list_students():
        filename = student.get("photo_filename")
        if not filename:
            continue
        path = PHOTO_DIR / filename
        if not path.exists():
            continue
        image = face_recognition.load_image_file(str(path))
        encs = face_recognition.face_encodings(image)
        if encs:
            known_encodings.append(encs[0])
            known_ids.append(student["id"])
    if not known_encodings:
        return None, 1.0

    distances = face_recognition.face_distance(known_encodings, encodings[0])
    best = int(np.argmin(distances))
    return (known_ids[best], float(distances[best])) if distances[best] < 0.5 else (None, float(distances[best]))


def recognize_frame(image_bytes: bytes) -> dict[str, Any]:
    """
    Detect faces in a webcam JPEG and identify the largest face.

    Returns a JSON-serializable status payload for the UI.
    """
    frame = decode_image_bytes(image_bytes)
    if frame is None:
        return {"status": "error", "message": "Could not decode the camera frame."}

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = detect_faces(gray)
    if not faces:
        return {
            "status": "no_face",
            "message": "No face detected. Face the camera in good lighting.",
            "faces": 0,
        }

    x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
    crop = gray[y : y + h, x : x + w]
    threshold = float(current_app.config["FACE_CONFIDENCE_THRESHOLD"])

    student_pk = None
    confidence = 999.0
    engine = "lbph"

    if _has_face_recognition():
        engine = "face_recognition"
        student_pk, distance = _match_face_recognition(frame)
        # Convert distance (0 best) into a comparable "confidence" display.
        confidence = round(distance * 100, 1)
        matched = student_pk is not None
    else:
        student_pk, confidence = _match_lbph(crop)
        matched = student_pk is not None and confidence <= threshold

    if not matched or student_pk is None:
        return {
            "status": "unknown",
            "message": "Face detected but not matched to a registered student.",
            "faces": len(faces),
            "confidence": round(confidence, 1),
            "engine": engine,
            "box": {"x": x, "y": y, "w": w, "h": h},
        }

    from app.models import get_student

    student = get_student(student_pk)
    if not student:
        return {"status": "unknown", "message": "Matched an obsolete face label.", "faces": len(faces)}

    return {
        "status": "recognized",
        "message": f"Recognized {student['full_name']}.",
        "faces": len(faces),
        "confidence": round(confidence, 1),
        "engine": engine,
        "student": {
            "id": student["id"],
            "student_id": student["student_id"],
            "full_name": student["full_name"],
            "roll_number": student["roll_number"],
            "department": student["department"],
        },
        "box": {"x": x, "y": y, "w": w, "h": h},
    }


def engine_status() -> dict[str, Any]:
    trained = len(list(FACE_DIR.glob("*.png")))
    return {
        "lbph": _lbph_available(),
        "face_recognition": _has_face_recognition(),
        "trained_faces": trained,
        "engine": "face_recognition" if _has_face_recognition() else "lbph",
    }
