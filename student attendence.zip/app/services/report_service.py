"""Excel and PDF attendance reports built from live database records."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from config import EXPORT_DIR
from app.models import attendance_for_date, attendance_for_month, attendance_for_student, student_performance
from app.utils import today_str


def _safe_name(prefix: str) -> Path:
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return EXPORT_DIR / f"{prefix}_{stamp}"


def _rows_to_frame(rows: list[dict]) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame(
            columns=["Date", "Time", "Student ID", "Name", "Roll", "Department", "Semester", "Method", "Status"]
        )
    return pd.DataFrame(
        [
            {
                "Date": r["attendance_date"],
                "Time": r["attendance_time"],
                "Student ID": r["student_id"],
                "Name": r["full_name"],
                "Roll": r["roll_number"],
                "Department": r["department"],
                "Semester": r.get("semester", ""),
                "Method": r["method"].upper(),
                "Status": r["status"].title(),
            }
            for r in rows
        ]
    )


def export_excel(kind: str, value: str) -> Path:
    if kind == "date":
        rows = attendance_for_date(value)
        prefix = f"attendance_{value}"
    elif kind == "month":
        rows = attendance_for_month(value)
        prefix = f"attendance_{value}"
    elif kind == "student":
        rows = attendance_for_student(int(value))
        prefix = f"student_{value}_attendance"
    elif kind == "performance":
        data = student_performance()
        frame = pd.DataFrame(
            [
                {
                    "Student ID": r["student_id"],
                    "Name": r["full_name"],
                    "Roll": r["roll_number"],
                    "Department": r["department"],
                    "Semester": r["semester"],
                    "Present Days": r["present_days"],
                    "Working Days": r["working_days"],
                    "Percentage": r["percentage"],
                }
                for r in data
            ]
        )
        path = _safe_name("performance").with_suffix(".xlsx")
        frame.to_excel(path, index=False, engine="openpyxl")
        return path
    else:
        raise ValueError("Unknown export kind.")

    frame = _rows_to_frame(rows)
    path = _safe_name(prefix).with_suffix(".xlsx")
    frame.to_excel(path, index=False, engine="openpyxl")
    return path


def export_pdf(kind: str, value: str, title: str) -> Path:
    if kind == "date":
        rows = attendance_for_date(value)
    elif kind == "month":
        rows = attendance_for_month(value)
    elif kind == "student":
        rows = attendance_for_student(int(value))
    elif kind == "performance":
        rows = student_performance()
    else:
        raise ValueError("Unknown export kind.")

    path = _safe_name("report").with_suffix(".pdf")
    doc = SimpleDocTemplate(
        str(path),
        pagesize=landscape(A4),
        leftMargin=12 * mm,
        rightMargin=12 * mm,
        topMargin=12 * mm,
        bottomMargin=12 * mm,
    )
    styles = getSampleStyleSheet()
    story = [
        Paragraph("Smart Attendance Management System", styles["Title"]),
        Paragraph(title, styles["Heading2"]),
        Paragraph(f"Generated on {datetime.now().strftime('%d %b %Y, %H:%M')}", styles["Normal"]),
        Spacer(1, 8),
    ]

    if kind == "performance":
        table_data = [["Student ID", "Name", "Roll", "Department", "Present", "Working Days", "%"]]
        for r in rows:
            table_data.append(
                [
                    r["student_id"],
                    r["full_name"],
                    r["roll_number"],
                    r["department"],
                    str(r["present_days"]),
                    str(r["working_days"]),
                    f"{r['percentage']}%",
                ]
            )
    else:
        table_data = [["Date", "Time", "Student ID", "Name", "Roll", "Method", "Status"]]
        for r in rows:
            table_data.append(
                [
                    r["attendance_date"],
                    r["attendance_time"],
                    r["student_id"],
                    r["full_name"],
                    r["roll_number"],
                    r["method"].upper(),
                    r["status"].title(),
                ]
            )

    if len(table_data) == 1:
        story.append(Paragraph("No records found for this selection.", styles["Normal"]))
    else:
        table = Table(table_data, repeatRows=1)
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e1b4b")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#c7d2fe")),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#eef2ff")]),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 6),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 6),
                ]
            )
        )
        story.append(table)

    doc.build(story)
    return path


def default_report_date() -> str:
    return today_str()
