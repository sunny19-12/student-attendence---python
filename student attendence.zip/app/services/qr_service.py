"""Signed QR attendance tokens.

A student QR payload is not a raw student ID. It is an HMAC-signed token
bound to a rotating per-student secret. Scanning only marks attendance
while an admin-opened QR session is active.
"""

from __future__ import annotations

import hmac
import hashlib
from io import BytesIO
from pathlib import Path

import qrcode
from flask import current_app
from PIL import Image, ImageDraw, ImageFont

from config import QR_DIR
from app.models import get_student, get_active_qr_session

PAYLOAD_PREFIX = "SAMS1"


def _sign(student_id: str, qr_secret: str, version: int) -> str:
    key = current_app.config["SECRET_KEY"].encode("utf-8")
    message = f"{student_id}|{qr_secret}|{version}".encode("utf-8")
    return hmac.new(key, message, hashlib.sha256).hexdigest()


def build_payload(student: dict) -> str:
    signature = _sign(student["student_id"], student["qr_secret"], int(student["qr_version"]))
    return f"{PAYLOAD_PREFIX}|{student['student_id']}|{student['qr_version']}|{signature}"


def parse_and_verify(raw: str) -> tuple[dict | None, str]:
    """Validate a scanned payload. Returns (student, error_message)."""
    text = (raw or "").strip()
    parts = text.split("|")
    if len(parts) != 4 or parts[0] != PAYLOAD_PREFIX:
        return None, "Invalid QR format. Use a system-generated student QR code."

    student_id, version_s, signature = parts[1], parts[2], parts[3]
    student = None
    from app.models import get_student_by_student_id

    student = get_student_by_student_id(student_id)
    if not student:
        return None, "This QR code is not linked to a registered student."

    try:
        version = int(version_s)
    except ValueError:
        return None, "Invalid QR version."

    if version != int(student["qr_version"]):
        return None, "This QR code has been revoked. Generate a new code for the student."

    expected = _sign(student["student_id"], student["qr_secret"], version)
    if not hmac.compare_digest(expected, signature):
        return None, "QR signature check failed. The code is not authentic."

    session = get_active_qr_session()
    if not session:
        return None, "No active QR attendance session. Start a session from the QR page first."

    return student, ""


def generate_qr_image(student: dict) -> Path:
    """Write a branded QR PNG and return its path."""
    QR_DIR.mkdir(parents=True, exist_ok=True)
    payload = build_payload(student)
    qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=8, border=2)
    qr.add_data(payload)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#0b1220", back_color="#eef2ff").convert("RGB")

    # Caption strip under the QR for easy identification (payload remains signed).
    caption = f"{student['full_name']}  ·  {student['student_id']}"
    padded = Image.new("RGB", (img.width, img.height + 42), "#0b1220")
    padded.paste(img, (0, 0))
    draw = ImageDraw.Draw(padded)
    try:
        font = ImageFont.load_default()
    except OSError:
        font = None
    draw.text((12, img.height + 12), caption[:48], fill="#c7d2fe", font=font)

    path = QR_DIR / f"{student['id']}.png"
    padded.save(path)
    return path
