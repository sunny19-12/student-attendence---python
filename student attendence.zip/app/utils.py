"""Shared helpers: validation, CSRF, file handling, and media serving."""

from __future__ import annotations

import re
import secrets
from datetime import datetime
from functools import wraps
from pathlib import Path

from flask import abort, current_app, redirect, send_file, session, url_for
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from config import PHOTO_DIR

STUDENT_ID_RE = re.compile(r"^[A-Za-z0-9_-]{3,20}$")
ROLL_RE = re.compile(r"^[A-Za-z0-9_-]{3,20}$")
NAME_RE = re.compile(r"^[A-Za-z .'-]{3,80}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def login_required(view):
    """Protect admin pages."""

    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("admin_id"):
            return redirect(url_for("login"))
        return view(*args, **kwargs)

    return wrapped


def ensure_csrf() -> str:
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


def validate_csrf(token: str | None) -> bool:
    expected = session.get("csrf_token")
    return bool(expected and token and secrets.compare_digest(expected, token))


def parse_date(value: str | None) -> str | None:
    if not value or not DATE_RE.match(value):
        return None
    try:
        datetime.strptime(value, "%Y-%m-%d")
        return value
    except ValueError:
        return None


def today_str() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def now_time_str() -> str:
    return datetime.now().strftime("%H:%M:%S")


def now_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def validate_student_fields(student_id: str, full_name: str, roll_number: str, department: str, semester: str) -> list[str]:
    errors: list[str] = []
    if not STUDENT_ID_RE.match((student_id or "").strip()):
        errors.append("Student ID must be 3-20 letters, numbers, hyphens or underscores.")
    if not NAME_RE.match((full_name or "").strip()):
        errors.append("Full name must be 3-80 letters (spaces and ' - . allowed).")
    if not ROLL_RE.match((roll_number or "").strip()):
        errors.append("Roll number must be 3-20 letters, numbers, hyphens or underscores.")
    departments = current_app.config["DEPARTMENTS"]
    if department not in departments:
        errors.append("Select a valid department.")
    if semester not in current_app.config["SEMESTERS"]:
        errors.append("Select a valid semester.")
    return errors


def save_student_photo(file: FileStorage, student_pk: int) -> str | None:
    """Store an uploaded photograph under a non-public data directory."""
    if not file or not file.filename:
        return None
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in current_app.config["ALLOWED_IMAGE_EXTENSIONS"]:
        raise ValueError("Photograph must be a PNG, JPG, JPEG or WEBP file.")
    filename = secure_filename(f"student_{student_pk}.{ext}")
    destination = PHOTO_DIR / filename
    file.stream.seek(0)
    file.save(destination)
    return filename


def send_protected_photo(filename: str):
    path = PHOTO_DIR / Path(filename).name
    if not path.exists():
        abort(404)
    return send_file(path)
