"""HTTP routes for authentication, students, attendance, recognition and reports."""

from __future__ import annotations

import base64
from datetime import datetime

from flask import (
    Flask,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)
from werkzeug.exceptions import RequestEntityTooLarge

from app.models import (
    attendance_for_date,
    attendance_for_month,
    attendance_for_student,
    authenticate_admin,
    close_qr_sessions,
    create_qr_session,
    create_student,
    dashboard_stats,
    delete_student,
    get_active_qr_session,
    get_student,
    list_students,
    mark_present,
    recent_attendance,
    rotate_qr_secret,
    set_student_photo,
    student_performance,
    update_student,
)
from app.services.face_service import engine_status, recognize_frame, register_student_face
from app.services.qr_service import generate_qr_image, parse_and_verify
from app.services.report_service import export_excel, export_pdf
from app.utils import (
    ensure_csrf,
    login_required,
    parse_date,
    save_student_photo,
    send_protected_photo,
    today_str,
    validate_csrf,
    validate_student_fields,
)
from config import BASE_DIR, Config, PHOTO_DIR


def register_routes(app: Flask) -> None:
    @app.context_processor
    def inject_globals():
        return {
            "csrf_token": ensure_csrf(),
            "admin_name": session.get("admin_username", ""),
            "current_year": datetime.now().year,
        }

    @app.errorhandler(RequestEntityTooLarge)
    def too_large(_e):
        flash("Uploaded file is too large (max 8 MB).", "danger")
        return redirect(request.referrer or url_for("students"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        ensure_csrf()
        if session.get("admin_id"):
            return redirect(url_for("dashboard"))
        if request.method == "POST":
            if not validate_csrf(request.form.get("csrf_token")):
                flash("Session expired. Please try again.", "danger")
                return redirect(url_for("login"))
            username = (request.form.get("username") or "").strip()
            password = request.form.get("password") or ""
            attempts = session.get("login_attempts", 0)
            if attempts >= 8:
                flash("Too many failed attempts. Restart the browser session and try later.", "danger")
                return render_template("login.html")
            admin = authenticate_admin(username, password)
            if not admin:
                session["login_attempts"] = attempts + 1
                flash("Invalid username or password.", "danger")
                return render_template("login.html")
            session.clear()
            session.permanent = True
            session["admin_id"] = admin["id"]
            session["admin_username"] = admin["username"]
            session["login_attempts"] = 0
            ensure_csrf()
            flash("Welcome back. You are signed in.", "success")
            return redirect(url_for("dashboard"))
        return render_template("login.html")

    @app.route("/logout", methods=["POST"])
    def logout():
        if not validate_csrf(request.form.get("csrf_token")):
            flash("Invalid logout request.", "danger")
            return redirect(url_for("dashboard"))
        session.clear()
        flash("You have been signed out.", "info")
        return redirect(url_for("login"))

    @app.route("/")
    @login_required
    def dashboard():
        stats = dashboard_stats()
        return render_template(
            "dashboard.html",
            stats=stats,
            recent=recent_attendance(12),
        )

    @app.route("/students")
    @login_required
    def students():
        q = request.args.get("q", "")
        return render_template("students/list.html", students=list_students(q), q=q)

    @app.route("/students/new", methods=["GET", "POST"])
    @login_required
    def student_new():
        if request.method == "POST":
            return _save_student(None)
        return render_template(
            "students/form.html",
            student=None,
            departments=Config.DEPARTMENTS,
            semesters=Config.SEMESTERS,
        )

    @app.route("/students/<int:student_pk>/edit", methods=["GET", "POST"])
    @login_required
    def student_edit(student_pk: int):
        student = get_student(student_pk)
        if not student:
            flash("Student not found.", "danger")
            return redirect(url_for("students"))
        if request.method == "POST":
            return _save_student(student_pk)
        return render_template(
            "students/form.html",
            student=student,
            departments=Config.DEPARTMENTS,
            semesters=Config.SEMESTERS,
        )

    def _save_student(student_pk: int | None):
        if not validate_csrf(request.form.get("csrf_token")):
            flash("Invalid form token. Refresh and try again.", "danger")
            return redirect(url_for("students"))
        data = {
            "student_id": request.form.get("student_id", ""),
            "full_name": request.form.get("full_name", ""),
            "roll_number": request.form.get("roll_number", ""),
            "department": request.form.get("department", ""),
            "semester": request.form.get("semester", ""),
        }
        errors = validate_student_fields(**data)
        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template(
                "students/form.html",
                student={"id": student_pk, **data} if student_pk else data,
                departments=Config.DEPARTMENTS,
                semesters=Config.SEMESTERS,
            )
        try:
            if student_pk is None:
                student_pk = create_student(data)
                flash("Student added successfully.", "success")
            else:
                update_student(student_pk, data)
                flash("Student details updated.", "success")
        except Exception as exc:
            message = str(exc).lower()
            if "unique" in message:
                flash("Student ID or roll number already exists.", "danger")
            else:
                flash("Could not save the student record.", "danger")
            return redirect(url_for("students"))

        photo = request.files.get("photo")
        if photo and photo.filename:
            try:
                filename = save_student_photo(photo, student_pk)
                if filename:
                    set_student_photo(student_pk, filename)
                    trained = register_student_face(student_pk, PHOTO_DIR / filename)
                    if trained:
                        flash("Photograph saved and face model updated.", "success")
                    else:
                        flash(
                            "Photograph saved, but no face was detected. Use a clear front-facing photo.",
                            "warning",
                        )
            except ValueError as exc:
                flash(str(exc), "danger")
        return redirect(url_for("student_view", student_pk=student_pk))

    @app.route("/students/<int:student_pk>")
    @login_required
    def student_view(student_pk: int):
        student = get_student(student_pk)
        if not student:
            flash("Student not found.", "danger")
            return redirect(url_for("students"))
        records = attendance_for_student(student_pk)
        present_days = sum(1 for r in records if r["status"] == "present")
        return render_template("students/view.html", student=student, records=records, present_days=present_days)

    @app.route("/students/<int:student_pk>/delete", methods=["POST"])
    @login_required
    def student_delete(student_pk: int):
        if not validate_csrf(request.form.get("csrf_token")):
            flash("Invalid form token.", "danger")
            return redirect(url_for("students"))
        student = get_student(student_pk)
        if student:
            delete_student(student_pk)
            flash(f"Deleted {student['full_name']}.", "info")
        return redirect(url_for("students"))

    @app.route("/students/<int:student_pk>/qr")
    @login_required
    def student_qr(student_pk: int):
        student = get_student(student_pk)
        if not student:
            flash("Student not found.", "danger")
            return redirect(url_for("students"))
        path = generate_qr_image(student)
        return send_file(path, mimetype="image/png", download_name=f"{student['student_id']}_qr.png")

    @app.route("/students/<int:student_pk>/qr/regenerate", methods=["POST"])
    @login_required
    def student_qr_regen(student_pk: int):
        if not validate_csrf(request.form.get("csrf_token")):
            flash("Invalid form token.", "danger")
            return redirect(url_for("students"))
        if not get_student(student_pk):
            flash("Student not found.", "danger")
            return redirect(url_for("students"))
        rotate_qr_secret(student_pk)
        generate_qr_image(get_student(student_pk))
        flash("QR code rotated. Previous codes will no longer work.", "success")
        return redirect(url_for("student_view", student_pk=student_pk))

    @app.route("/media/students/<int:student_pk>/photo")
    @login_required
    def student_photo(student_pk: int):
        student = get_student(student_pk)
        if not student or not student.get("photo_filename"):
            return send_file(BASE_DIR / "static" / "img" / "avatar.svg", mimetype="image/svg+xml")
        return send_protected_photo(student["photo_filename"])

    @app.route("/attendance")
    @login_required
    def attendance():
        day = parse_date(request.args.get("date")) or today_str()
        month = request.args.get("month") or day[:7]
        if len(month) != 7 or month[4] != "-":
            month = day[:7]
        student_pk = request.args.get("student_id", type=int)
        view = request.args.get("view", "daily")
        records = []
        selected_student = None
        if view == "monthly":
            records = attendance_for_month(month)
        elif view == "student" and student_pk:
            selected_student = get_student(student_pk)
            records = attendance_for_student(student_pk) if selected_student else []
        else:
            view = "daily"
            records = attendance_for_date(day)
        all_students = list_students()
        present_ids = {r["student_pk"] for r in attendance_for_date(day) if r["status"] == "present"}
        absentees = [s for s in all_students if s["id"] not in present_ids]
        return render_template(
            "attendance/index.html",
            view=view,
            day=day,
            month=month,
            records=records,
            students=all_students,
            selected_student=selected_student,
            absentees=absentees,
        )

    @app.route("/attendance/manual", methods=["POST"])
    @login_required
    def attendance_manual():
        if not validate_csrf(request.form.get("csrf_token")):
            flash("Invalid form token.", "danger")
            return redirect(url_for("attendance"))
        student_pk = request.form.get("student_pk", type=int)
        day = parse_date(request.form.get("date")) or today_str()
        if not student_pk or not get_student(student_pk):
            flash("Select a valid student.", "danger")
            return redirect(url_for("attendance"))
        created, message = mark_present(student_pk, "manual", day)
        flash(message, "success" if created else "warning")
        return redirect(url_for("attendance", date=day))

    @app.route("/attendance/face")
    @login_required
    def attendance_face():
        return render_template("attendance/face.html", engine=engine_status(), today=today_str())

    @app.route("/api/face/recognize", methods=["POST"])
    @login_required
    def api_face_recognize():
        if not validate_csrf(request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")):
            return {"ok": False, "message": "Invalid CSRF token."}, 400
        payload = request.form.get("image") or ""
        if "," in payload:
            payload = payload.split(",", 1)[1]
        try:
            image_bytes = base64.b64decode(payload)
        except Exception:
            return {"ok": False, "message": "Invalid image data."}, 400
        result = recognize_frame(image_bytes)
        if result.get("status") == "recognized":
            created, message = mark_present(result["student"]["id"], "face")
            result["attendance"] = {"created": created, "message": message}
            result["timestamp"] = datetime.now().strftime("%d %b %Y, %H:%M:%S")
        return {"ok": True, **result}

    @app.route("/attendance/qr")
    @login_required
    def attendance_qr():
        return render_template(
            "attendance/qr.html",
            qr_session=get_active_qr_session(),
            students=list_students(),
            today=today_str(),
        )

    @app.route("/attendance/qr/session", methods=["POST"])
    @login_required
    def attendance_qr_session():
        if not validate_csrf(request.form.get("csrf_token")):
            flash("Invalid form token.", "danger")
            return redirect(url_for("attendance_qr"))
        action = request.form.get("action")
        if action == "start":
            create_qr_session(Config.QR_SESSION_MINUTES)
            flash(f"QR attendance session started for {Config.QR_SESSION_MINUTES} minutes.", "success")
        else:
            close_qr_sessions()
            flash("QR attendance session closed.", "info")
        return redirect(url_for("attendance_qr"))

    @app.route("/api/qr/scan", methods=["POST"])
    @login_required
    def api_qr_scan():
        if not validate_csrf(request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")):
            return {"ok": False, "message": "Invalid CSRF token."}, 400
        raw = (request.form.get("payload") or "").strip()
        student, error = parse_and_verify(raw)
        if error:
            return {"ok": False, "status": "rejected", "message": error}
        created, message = mark_present(student["id"], "qr")
        return {
            "ok": True,
            "status": "accepted" if created else "duplicate",
            "message": message,
            "timestamp": datetime.now().strftime("%d %b %Y, %H:%M:%S"),
            "student": {
                "id": student["id"],
                "student_id": student["student_id"],
                "full_name": student["full_name"],
                "roll_number": student["roll_number"],
                "department": student["department"],
            },
        }

    @app.route("/reports")
    @login_required
    def reports():
        return render_template(
            "reports/index.html",
            students=list_students(),
            performance=student_performance(),
            today=today_str(),
            month=today_str()[:7],
        )

    @app.route("/reports/export", methods=["POST"])
    @login_required
    def reports_export():
        if not validate_csrf(request.form.get("csrf_token")):
            flash("Invalid form token.", "danger")
            return redirect(url_for("reports"))
        fmt = request.form.get("format", "xlsx")
        kind = request.form.get("kind", "date")
        value = (request.form.get("value") or "").strip()
        try:
            if kind == "date":
                value = parse_date(value) or today_str()
                title = f"Daily attendance — {value}"
            elif kind == "month":
                if len(value) != 7:
                    value = today_str()[:7]
                title = f"Monthly attendance — {value}"
            elif kind == "student":
                title = "Student attendance report"
            else:
                kind = "performance"
                value = "all"
                title = "Student performance report"
            if fmt == "pdf":
                path = export_pdf(kind, value, title)
            else:
                path = export_excel(kind, value)
        except Exception as exc:
            flash(f"Could not generate the report: {exc}", "danger")
            return redirect(url_for("reports"))
        return send_file(path, as_attachment=True, download_name=path.name)

    @app.route("/health")
    def health():
        return {"ok": True, "app": "Smart Attendance Management System"}
