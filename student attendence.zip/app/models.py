"""Data-access functions for admins, students, attendance and sessions."""

from __future__ import annotations

import secrets
from typing import Any

from werkzeug.security import check_password_hash

from app.db import execute, query_all, query_one
from app.utils import now_stamp, now_time_str, today_str


def authenticate_admin(username: str, password: str) -> dict[str, Any] | None:
    row = query_one("SELECT * FROM admins WHERE username = ?", (username.strip(),))
    if not row or not check_password_hash(row["password_hash"], password):
        return None
    return dict(row)


def get_student(student_pk: int) -> dict[str, Any] | None:
    row = query_one("SELECT * FROM students WHERE id = ?", (student_pk,))
    return dict(row) if row else None


def get_student_by_student_id(student_id: str) -> dict[str, Any] | None:
    row = query_one("SELECT * FROM students WHERE student_id = ?", (student_id,))
    return dict(row) if row else None


def list_students(search: str = "") -> list[dict[str, Any]]:
    search = (search or "").strip()
    if search:
        like = f"%{search}%"
        rows = query_all(
            """
            SELECT * FROM students
            WHERE student_id LIKE ? OR full_name LIKE ? OR roll_number LIKE ?
                  OR department LIKE ?
            ORDER BY full_name COLLATE NOCASE
            """,
            (like, like, like, like),
        )
    else:
        rows = query_all("SELECT * FROM students ORDER BY full_name COLLATE NOCASE")
    return [dict(r) for r in rows]


def create_student(data: dict[str, str]) -> int:
    now = now_stamp()
    return execute(
        """
        INSERT INTO students (
            student_id, full_name, roll_number, department, semester,
            photo_filename, qr_secret, qr_version, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, NULL, ?, 1, ?, ?)
        """,
        (
            data["student_id"].strip(),
            data["full_name"].strip(),
            data["roll_number"].strip(),
            data["department"],
            data["semester"],
            secrets.token_urlsafe(32),
            now,
            now,
        ),
    )


def update_student(student_pk: int, data: dict[str, str]) -> None:
    execute(
        """
        UPDATE students
        SET student_id = ?, full_name = ?, roll_number = ?, department = ?,
            semester = ?, updated_at = ?
        WHERE id = ?
        """,
        (
            data["student_id"].strip(),
            data["full_name"].strip(),
            data["roll_number"].strip(),
            data["department"],
            data["semester"],
            now_stamp(),
            student_pk,
        ),
    )


def set_student_photo(student_pk: int, filename: str) -> None:
    execute(
        "UPDATE students SET photo_filename = ?, updated_at = ? WHERE id = ?",
        (filename, now_stamp(), student_pk),
    )


def rotate_qr_secret(student_pk: int) -> None:
    execute(
        """
        UPDATE students
        SET qr_secret = ?, qr_version = qr_version + 1, updated_at = ?
        WHERE id = ?
        """,
        (secrets.token_urlsafe(32), now_stamp(), student_pk),
    )


def delete_student(student_pk: int) -> None:
    execute("DELETE FROM students WHERE id = ?", (student_pk,))


def mark_present(student_pk: int, method: str, attendance_date: str | None = None) -> tuple[bool, str]:
    """Mark a student present. Returns (created, message). Duplicate dates are rejected."""
    day = attendance_date or today_str()
    existing = query_one(
        "SELECT id, status, method FROM attendance WHERE student_pk = ? AND attendance_date = ?",
        (student_pk, day),
    )
    if existing:
        return False, "Attendance already marked for this student today."
    execute(
        """
        INSERT INTO attendance (
            student_pk, attendance_date, attendance_time, method, status, created_at
        ) VALUES (?, ?, ?, ?, 'present', ?)
        """,
        (student_pk, day, now_time_str(), method, now_stamp()),
    )
    return True, "Attendance marked successfully."


def attendance_for_date(day: str) -> list[dict[str, Any]]:
    rows = query_all(
        """
        SELECT a.*, s.student_id, s.full_name, s.roll_number, s.department, s.semester
        FROM attendance a
        JOIN students s ON s.id = a.student_pk
        WHERE a.attendance_date = ?
        ORDER BY a.attendance_time DESC
        """,
        (day,),
    )
    return [dict(r) for r in rows]


def attendance_for_month(year_month: str) -> list[dict[str, Any]]:
    rows = query_all(
        """
        SELECT a.*, s.student_id, s.full_name, s.roll_number, s.department, s.semester
        FROM attendance a
        JOIN students s ON s.id = a.student_pk
        WHERE a.attendance_date LIKE ?
        ORDER BY a.attendance_date, s.full_name
        """,
        (f"{year_month}%",),
    )
    return [dict(r) for r in rows]


def attendance_for_student(student_pk: int) -> list[dict[str, Any]]:
    rows = query_all(
        """
        SELECT a.*, s.student_id, s.full_name, s.roll_number, s.department, s.semester
        FROM attendance a
        JOIN students s ON s.id = a.student_pk
        WHERE a.student_pk = ?
        ORDER BY a.attendance_date DESC
        """,
        (student_pk,),
    )
    return [dict(r) for r in rows]


def recent_attendance(limit: int = 10) -> list[dict[str, Any]]:
    rows = query_all(
        """
        SELECT a.*, s.student_id, s.full_name, s.roll_number, s.department
        FROM attendance a
        JOIN students s ON s.id = a.student_pk
        ORDER BY a.created_at DESC
        LIMIT ?
        """,
        (limit,),
    )
    return [dict(r) for r in rows]


def dashboard_stats() -> dict[str, Any]:
    total = query_one("SELECT COUNT(*) AS c FROM students")["c"]
    day = today_str()
    present = query_one(
        "SELECT COUNT(*) AS c FROM attendance WHERE attendance_date = ? AND status = 'present'",
        (day,),
    )["c"]
    absent = max(total - present, 0)
    percentage = round((present / total) * 100, 1) if total else 0.0
    trend_rows = query_all(
        """
        SELECT attendance_date AS day, COUNT(*) AS present_count
        FROM attendance
        WHERE status = 'present'
          AND attendance_date >= date('now', '-13 days')
        GROUP BY attendance_date
        ORDER BY attendance_date
        """
    )
    trend = {r["day"]: r["present_count"] for r in trend_rows}
    from datetime import datetime, timedelta

    labels = []
    values = []
    today = datetime.now().date()
    for i in range(13, -1, -1):
        d = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        labels.append(d[5:])  # MM-DD
        values.append(int(trend.get(d, 0)))
    return {
        "total_students": total,
        "present_today": present,
        "absent_today": absent,
        "percentage": percentage,
        "chart_labels": labels,
        "chart_values": values,
        "today": day,
    }


def student_performance() -> list[dict[str, Any]]:
    rows = query_all(
        """
        SELECT
            s.id, s.student_id, s.full_name, s.roll_number, s.department, s.semester,
            COUNT(a.id) AS present_days
        FROM students s
        LEFT JOIN attendance a ON a.student_pk = s.id AND a.status = 'present'
        GROUP BY s.id
        ORDER BY s.full_name COLLATE NOCASE
        """
    )
    working_days = query_one("SELECT COUNT(DISTINCT attendance_date) AS c FROM attendance")["c"] or 0
    result = []
    for r in rows:
        present_days = r["present_days"]
        pct = round((present_days / working_days) * 100, 1) if working_days else 0.0
        result.append({**dict(r), "working_days": working_days, "percentage": pct})
    return result


def create_qr_session(minutes: int) -> dict[str, Any]:
    from datetime import datetime, timedelta

    execute("UPDATE attendance_sessions SET is_active = 0 WHERE method = 'qr' AND is_active = 1")
    start = datetime.now()
    expires = start + timedelta(minutes=minutes)
    token = secrets.token_urlsafe(24)
    pk = execute(
        """
        INSERT INTO attendance_sessions (method, session_token, is_active, started_at, expires_at)
        VALUES ('qr', ?, 1, ?, ?)
        """,
        (token, start.strftime("%Y-%m-%d %H:%M:%S"), expires.strftime("%Y-%m-%d %H:%M:%S")),
    )
    return {
        "id": pk,
        "session_token": token,
        "started_at": start.strftime("%Y-%m-%d %H:%M:%S"),
        "expires_at": expires.strftime("%Y-%m-%d %H:%M:%S"),
        "is_active": 1,
    }


def get_active_qr_session() -> dict[str, Any] | None:
    row = query_one(
        """
        SELECT * FROM attendance_sessions
        WHERE method = 'qr' AND is_active = 1
        ORDER BY id DESC LIMIT 1
        """
    )
    if not row:
        return None
    session = dict(row)
    if session["expires_at"] < now_stamp():
        execute("UPDATE attendance_sessions SET is_active = 0 WHERE id = ?", (session["id"],))
        return None
    return session


def close_qr_sessions() -> None:
    execute("UPDATE attendance_sessions SET is_active = 0 WHERE method = 'qr'")
