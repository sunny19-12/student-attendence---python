"""SQLite helpers with parameterized queries only."""

from __future__ import annotations

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

from flask import Flask, current_app, g
from werkzeug.security import generate_password_hash

from config import Config


def get_connection() -> sqlite3.Connection:
    """Return a request-scoped SQLite connection."""
    if "db" not in g:
        path: Path = current_app.config["DATABASE_PATH"]
        path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(path, detect_types=sqlite3.PARSE_DECLTYPES)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        g.db = conn
    return g.db


def close_connection(_error: BaseException | None = None) -> None:
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def query_all(sql: str, params: Iterable[Any] = ()) -> list[sqlite3.Row]:
    return get_connection().execute(sql, tuple(params)).fetchall()


def query_one(sql: str, params: Iterable[Any] = ()) -> sqlite3.Row | None:
    return get_connection().execute(sql, tuple(params)).fetchone()


def execute(sql: str, params: Iterable[Any] = ()) -> int:
    conn = get_connection()
    cur = conn.execute(sql, tuple(params))
    conn.commit()
    return int(cur.lastrowid)


def init_schema() -> None:
    """Create tables if they do not exist."""
    conn = get_connection()
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS admins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT NOT NULL UNIQUE,
            full_name TEXT NOT NULL,
            roll_number TEXT NOT NULL UNIQUE,
            department TEXT NOT NULL,
            semester TEXT NOT NULL,
            photo_filename TEXT,
            qr_secret TEXT NOT NULL,
            qr_version INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_pk INTEGER NOT NULL,
            attendance_date TEXT NOT NULL,
            attendance_time TEXT NOT NULL,
            method TEXT NOT NULL CHECK (method IN ('face', 'qr', 'manual')),
            status TEXT NOT NULL CHECK (status IN ('present', 'absent')),
            created_at TEXT NOT NULL,
            FOREIGN KEY (student_pk) REFERENCES students(id) ON DELETE CASCADE,
            UNIQUE (student_pk, attendance_date)
        );

        CREATE TABLE IF NOT EXISTS attendance_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            method TEXT NOT NULL,
            session_token TEXT NOT NULL UNIQUE,
            is_active INTEGER NOT NULL DEFAULT 1,
            started_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(attendance_date);
        CREATE INDEX IF NOT EXISTS idx_students_name ON students(full_name);
        """
    )
    conn.commit()


def seed_defaults() -> None:
    """Insert the default admin account and sample students if the database is empty."""
    if query_one("SELECT id FROM admins LIMIT 1"):
        return

    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    execute(
        "INSERT INTO admins (username, password_hash, created_at) VALUES (?, ?, ?)",
        (
            Config.DEFAULT_ADMIN_USERNAME,
            generate_password_hash(Config.DEFAULT_ADMIN_PASSWORD),
            now,
        ),
    )

    import secrets

    samples = [
        ("STU1001", "Aarav Sharma", "CSE21-001", "Computer Science and Engineering", "6"),
        ("STU1002", "Diya Patel", "CSE21-002", "Computer Science and Engineering", "6"),
        ("STU1003", "Rohan Mehta", "CSE21-003", "Computer Science and Engineering", "6"),
        ("STU1004", "Ananya Iyer", "IT21-014", "Information Technology", "6"),
        ("STU1005", "Kabir Singh", "ECE21-021", "Electronics and Communication Engineering", "5"),
        ("STU1006", "Meera Nair", "ECE21-022", "Electronics and Communication Engineering", "5"),
        ("STU1007", "Ishaan Gupta", "ME21-031", "Mechanical Engineering", "4"),
        ("STU1008", "Sneha Reddy", "CE21-041", "Civil Engineering", "4"),
    ]
    for student_id, name, roll, dept, sem in samples:
        execute(
            """
            INSERT INTO students (
                student_id, full_name, roll_number, department, semester,
                photo_filename, qr_secret, qr_version, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, NULL, ?, 1, ?, ?)
            """,
            (student_id, name, roll, dept, sem, secrets.token_urlsafe(32), now, now),
        )


def init_app(app: Flask) -> None:
    app.teardown_appcontext(close_connection)

    @app.before_request
    def _ensure_db() -> None:
        # Schema creation is cheap with IF NOT EXISTS.
        init_schema()
        seed_defaults()
