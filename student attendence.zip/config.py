"""Application configuration for Smart Attendance Management System."""

from __future__ import annotations

import os
import secrets
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
DATA_DIR = BASE_DIR / "data"
PHOTO_DIR = DATA_DIR / "photos"
FACE_DIR = DATA_DIR / "faces"
QR_DIR = DATA_DIR / "qrcodes"
MODEL_DIR = DATA_DIR / "models"
EXPORT_DIR = BASE_DIR / "exports"


def _load_or_create_secret() -> str:
    """Persist a secret key so sessions survive server restarts."""
    INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
    secret_file = INSTANCE_DIR / "secret.key"
    if secret_file.exists():
        return secret_file.read_text(encoding="utf-8").strip()
    value = secrets.token_hex(32)
    secret_file.write_text(value, encoding="utf-8")
    return value


class Config:
    SECRET_KEY = os.environ.get("SAMS_SECRET_KEY", _load_or_create_secret())
    DATABASE_PATH = INSTANCE_DIR / "attendance.db"
    MAX_CONTENT_LENGTH = 8 * 1024 * 1024  # 8 MB upload cap
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = False  # local development
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 8  # 8 hours
    ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
    QR_SESSION_MINUTES = 30
    FACE_CONFIDENCE_THRESHOLD = 70.0  # LBPH: lower distance is better
    DEFAULT_ADMIN_USERNAME = "admin"
    DEFAULT_ADMIN_PASSWORD = "Admin@123"
    DEPARTMENTS = (
        "Computer Science and Engineering",
        "Electronics and Communication Engineering",
        "Electrical Engineering",
        "Mechanical Engineering",
        "Civil Engineering",
        "Information Technology",
    )
    SEMESTERS = tuple(str(i) for i in range(1, 9))
