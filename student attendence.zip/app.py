"""Run the Smart Attendance Management System locally.

Usage (from the project root, with the virtual environment active):

    python app.py
"""

from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
