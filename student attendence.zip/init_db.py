"""Initialize the SQLite database and sample records from the command line."""

from app import create_app
from app.db import init_schema, seed_defaults

if __name__ == "__main__":
    application = create_app()
    with application.app_context():
        init_schema()
        seed_defaults()
        print("Database ready at instance/attendance.db")
        print("Admin login: admin / Admin@123")
        print("Sample students STU1001–STU1008 have been inserted if the database was empty.")
