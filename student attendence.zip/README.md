# Smart Attendance Management System

Face Recognition + QR Code attendance for a B.Tech final-year project.

The application is a Flask dashboard that stores live student and attendance data in SQLite. Dashboard numbers are queried from the database (they are not placeholders). Photographs are stored outside the public static folder and are only served to a signed-in admin.

## Features

- Secure admin login with hashed passwords and CSRF-protected forms
- Student management (add, edit, delete, search, photograph)
- Face attendance with OpenCV (LBPH). Optional `face_recognition` if you install it separately
- Signed QR attendance tokens and a timed admin session (static student IDs cannot mark attendance)
- Duplicate attendance blocked per student per calendar day
- Daily / monthly / student-wise records
- Excel and PDF exports from live data

## Requirements

- Python 3.11 or 3.12 (64-bit)
- A webcam for face and QR capture
- Windows, macOS or Linux

The default engine uses `opencv-contrib-python` (LBPH). The `face_recognition` / dlib stack is optional because it often fails to build on current Windows Python versions.

## Installation (VS Code)

1. Open this folder in VS Code.
2. Create and activate a virtual environment:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

On macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

3. Initialize the database (optional; the app also creates it on first request):

```powershell
python init_db.py
```

4. Run the server:

```powershell
python app.py
```

5. Open [http://127.0.0.1:5000](http://127.0.0.1:5000)

### Default admin

| Username | Password   |
|----------|------------|
| `admin`  | `Admin@123` |

Change this password in production by updating the `admins` table after hashing a new password with `werkzeug.security.generate_password_hash`.

Sample students `STU1001`–`STU1008` are inserted on first launch. Upload a front-facing photograph for each student before using face recognition.

## Using attendance

### Face recognition

1. Add a student photograph (clear, front face).
2. Open **Face Attendance** and allow the browser camera.
3. The server detects a face with Haar cascades and identifies it with LBPH (or `face_recognition` if installed).
4. A successful match marks **present** for today. A second match the same day is rejected.

### QR attendance

1. Open a student profile and download the signed QR image (or regenerate it to revoke old prints).
2. On **QR Attendance**, start a 30-minute session.
3. Scan the code. The payload is HMAC-signed and bound to a rotating secret. Scanning without an active session is rejected.

## Project layout

```
app.py                 # development entry point
init_db.py             # database bootstrap
config.py              # paths and security settings
requirements.txt
app/
  __init__.py          # Flask factory
  db.py                # SQLite schema
  models.py            # queries
  routes.py            # HTTP endpoints
  utils.py             # validation, CSRF, photo storage
  services/            # face, QR, reports
  templates/           # Bootstrap 5 UI
static/                # CSS / JS (no student photos)
instance/attendance.db # created at runtime
data/photos            # private photographs
data/faces             # cropped training faces
data/qrcodes           # generated QR images
exports/               # Excel / PDF output
```

## Security notes

- Passwords use Werkzeug password hashing
- SQL is parameterized (no string-built queries)
- Sessions are HTTP-only with SameSite=Lax
- Student photographs are not stored under `/static`
- QR codes are HMAC-signed and session-gated

## Optional: dlib face_recognition

If you already have a working `dlib` build:

```powershell
pip install face_recognition
```

The app will use it automatically when the import succeeds; otherwise it stays on OpenCV LBPH.
